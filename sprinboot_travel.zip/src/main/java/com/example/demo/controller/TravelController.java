package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Booking;
import com.example.demo.model.Travel;
import com.example.demo.dao.BookingDao;
import com.example.demo.dao.TravelDao;
import com.example.demo.service.TravelService;
/*@Configuration(locations = {
"classpath*:spring/applicationContext.xml",
"classpath*:spring/applicationContext-jpa.xml",
"classpath*:spring/applicationContext-security.xml" })*/



@RestController
public class TravelController {

	
	@Autowired
	public TravelDao dao;
	@Autowired
	public BookingDao dao1;
	
	
	@GetMapping("/features")
	
	public List<Travel> getPlace(){
		System.out.println("REceived request");
		return (List<Travel>) dao.findAll();
	}
@GetMapping("/booking")
	
	public List<Booking> getDetail(){
		System.out.println("REceived deatail");
		return (List<Booking>) dao1.findAll();
	}
	
	
	
}
