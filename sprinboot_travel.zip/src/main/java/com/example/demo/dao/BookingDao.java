package com.example.demo.dao;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Booking;


public interface BookingDao extends CrudRepository<Booking,Integer> {

}
